import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createMockContext(): TrpcContext {
  return {
    user: undefined,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Quiz Integration with SALESmanago", () => {
  it("should successfully submit quiz results to SALESmanago", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const testEmail = `test+${Date.now()}@example.com`;

    const result = await caller.quiz.submitQuizResults({
      email: testEmail,
      name: "Test User",
      quizAnswers: {
        q1: "breath",
        q2: "home",
        q3: "bath",
      },
      recommendedProducts: ["Sól do kąpieli Liptus®", "Maść aromaterapeutyczna Liptus®"],
    });

    expect(result.success).toBe(true);
    expect(result.message).toContain("SALESmanago");
  }, 15000); // 15s timeout for API call

  it("should handle missing email gracefully", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.quiz.submitQuizResults({
        email: "", // Invalid email
        quizAnswers: {},
        recommendedProducts: [],
      })
    ).rejects.toThrow();
  });
});
