import crypto from "crypto";
import axios from "axios";

const SALESMANAGO_CLIENT_ID = process.env.SALESMANAGO_CLIENT_ID;
const SALESMANAGO_API_KEY = process.env.SALESMANAGO_API_KEY;
const SALESMANAGO_API_SECRET = process.env.SALESMANAGO_API_SECRET;
const SALESMANAGO_ENDPOINT = process.env.SALESMANAGO_ENDPOINT || "app3.salesmanago.com";
const SALESMANAGO_OWNER_EMAIL = process.env.SALESMANAGO_OWNER_EMAIL;

if (!SALESMANAGO_CLIENT_ID || !SALESMANAGO_API_KEY || !SALESMANAGO_API_SECRET || !SALESMANAGO_OWNER_EMAIL) {
  console.warn(
    "[SALESmanago] Missing credentials. Set SALESMANAGO_CLIENT_ID, SALESMANAGO_API_KEY, SALESMANAGO_API_SECRET, and SALESMANAGO_OWNER_EMAIL."
  );
}

/**
 * Add or update contact in SALESmanago
 * Refactored to match the provided pattern:
 * - Uses SHA1(apiKey + clientId + apiSecret)
 * - Correct payload structure
 */
export async function addContactToSalesManago(params: {
  email: string;
  name?: string;
  tags?: string[];
  customFields?: Record<string, string>;
}) {
  if (!SALESMANAGO_CLIENT_ID || !SALESMANAGO_API_KEY || !SALESMANAGO_API_SECRET || !SALESMANAGO_OWNER_EMAIL) {
    throw new Error("SALESmanago credentials not configured");
  }

  const { email, name, tags = [] } = params;

  // Generowanie SHA1(apiKey + clientId + apiSecret) zgodnie ze wzorcem
  const sha = crypto
    .createHash("sha1")
    .update(`${SALESMANAGO_API_KEY}${SALESMANAGO_CLIENT_ID}${SALESMANAGO_API_SECRET}`)
    .digest("hex");

  // Tworzymy payload dla SALESmanago zgodnie ze wzorcem
  const payload = {
    clientId: SALESMANAGO_CLIENT_ID,
    apiKey: SALESMANAGO_API_KEY,
    requestTime: new Date().getTime(),
    sha,
    owner: SALESMANAGO_OWNER_EMAIL,
    contact: { 
      email, 
      name: name || "" 
    },
    forceOptIn: true,
    tags, // PRZEKAZANE Z FRONTENDU
  };

  console.log("[SALESmanago] Sending data to SALESmanago:", JSON.stringify(payload, null, 2));

  try {
    const response = await axios.post(
      `https://${SALESMANAGO_ENDPOINT}/api/contact/upsert`,
      payload,
      {
        headers: {
          "Content-Type": "application/json;charset=UTF-8",
          "Accept": "application/json",
        },
        timeout: 10000,
      }
    );

    const data = response.data;
    console.log("[SALESmanago] Response from SALESmanago:", data);

    if (data.success) {
      return {
        success: true,
        data: data,
      };
    } else {
      throw new Error(`SALESmanago error: ${JSON.stringify(data)}`);
    }
  } catch (error: any) {
    console.error("[SALESmanago] Error adding contact:", error.response?.data || error.message);
    throw new Error(
      `Failed to add contact to SALESmanago: ${error.response?.data?.message || error.message}`
    );
  }
}

/**
 * Test SALESmanago connection
 */
export async function testSalesManagoConnection(): Promise<boolean> {
  if (!SALESMANAGO_CLIENT_ID || !SALESMANAGO_API_KEY || !SALESMANAGO_API_SECRET || !SALESMANAGO_OWNER_EMAIL) {
    return false;
  }

  try {
    const testEmail = `test+${Date.now()}@example.com`;
    await addContactToSalesManago({
      email: testEmail,
      name: "Test Connection",
      tags: ["TEST_CONNECTION"],
    });
    return true;
  } catch (error) {
    console.error("[SALESmanago] Connection test failed:", error);
    return false;
  }
}
