import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { addContactToSalesManago } from "./salesmanago";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Quiz funnel integration with SALESmanago
  quiz: router({
    submitQuizResults: publicProcedure
      .input(
        z.object({
          email: z.string().email(),
          name: z.string().optional(),
          quizAnswers: z.record(z.string(), z.any()),
          recommendedProducts: z.array(z.string()),
          ritualTitle: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { email, name, quizAnswers, recommendedProducts, ritualTitle } = input;

        // Prepare tags for SALESmanago
        const tags = [
          "liptus_quiz_completed",
        ];

        if (ritualTitle) {
          // Funkcja do usuwania polskich znaków
          const removePolishChars = (str: string) => {
            const map: Record<string, string> = {
              'ą': 'a', 'ć': 'c', 'ę': 'e', 'ł': 'l', 'ń': 'n', 'ó': 'o', 'ś': 's', 'ź': 'z', 'ż': 'z',
              'Ą': 'A', 'Ć': 'C', 'Ę': 'E', 'Ł': 'L', 'Ń': 'N', 'Ó': 'O', 'Ś': 'S', 'Ź': 'Z', 'Ż': 'Z'
            };
            return str.replace(/[ąćęłńóśźżĄĆĘŁŃÓŚŹŻ]/g, match => map[match]);
          };

          // Convert "Twój Rytuał: Oddech w Kąpieli" to "oddech_w_kapieli"
          const cleanTitle = removePolishChars(ritualTitle)
            .replace("Twoj Rytual:", "")
            .trim()
            .toLowerCase()
            .replace(/[^a-z0-9\s]/g, "")
            .replace(/\s+/g, "_");
          
          tags.push(cleanTitle);
        }

        // Prepare custom fields
        const customFields: Record<string, string> = {
          quiz_completed_at: new Date().toISOString(),
          recommended_products: recommendedProducts.join(", "),
        };

        // Add quiz answers as custom fields
        Object.entries(quizAnswers).forEach(([key, value]) => {
          customFields[`quiz_${key}`] = String(value);
        });

        try {
          // Send to SALESmanago
          await addContactToSalesManago({
            email,
            name,
            tags,
            customFields,
          });

          return {
            success: true,
            message: "Quiz results sent to SALESmanago successfully",
          };
        } catch (error: any) {
          console.error("[Quiz] Failed to send to SALESmanago:", error);
          throw new Error(`Failed to save quiz results: ${error.message}`);
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
