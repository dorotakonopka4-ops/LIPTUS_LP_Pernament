import { describe, expect, it } from "vitest";
import { testSalesManagoConnection } from "./salesmanago";

describe("SALESmanago Integration", () => {
  it("should successfully connect to SALESmanago API", async () => {
    const isConnected = await testSalesManagoConnection();
    expect(isConnected).toBe(true);
  }, 15000); // 15s timeout for API call
});
