CREATE TABLE `quiz_leads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`name` varchar(255),
	`quiz_answers` text,
	`recommended_products` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quiz_leads_id` PRIMARY KEY(`id`)
);
