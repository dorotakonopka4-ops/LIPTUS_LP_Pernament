import { useState } from "react";
import DiscountBanner from "@/components/DiscountBanner";
import QuizHero from "@/components/QuizHero";
import QuizFunnel from "@/components/QuizFunnel";
import AnimatedTRPM8 from "@/components/AnimatedTRPM8";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Sparkles, Heart, Leaf, ShieldCheck } from "lucide-react";
import { trackABTestEvent } from "@/lib/abtest";

/**
 * Home Variant B - Quiz-First approach
 * For A/B testing: Quiz hero → Products → Storytelling
 */

export default function HomeVariantB() {
  const [isQuizOpen, setIsQuizOpen] = useState(false);

  const handleQuizOpen = () => {
    trackABTestEvent('quiz_started');
    setIsQuizOpen(true);
  };

  return (
    <div className="min-h-screen">
      {/* Discount Banner */}
      <DiscountBanner />
      
      {/* Quiz-First Hero */}
      <QuizHero onQuizClick={handleQuizOpen} />

      {/* Social Proof Bar */}
      <section className="bg-primary/10 py-4">
        <div className="container">
          <div className="flex flex-wrap items-center justify-center gap-8 text-sm text-foreground">
            <div className="flex items-center gap-2">
              <span className="text-2xl">★★★★★</span>
              <span className="font-medium">
                15,908 zadowolonych klientów
              </span>
            </div>
            <div className="h-4 w-px bg-border" />
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-primary" />
              <span>100% naturalne składniki</span>
            </div>
            <div className="h-4 w-px bg-border" />
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-primary" />
              <span>Ręczna produkcja w małych partiach</span>
            </div>
          </div>
        </div>
      </section>

      {/* Top 3 Products - moved up */}
      <section id="products" className="py-20 bg-background">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-5xl font-semibold mb-4">
              Poznaj serię Liptus®
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Trzy najpopularniejsze produkty, które pokochały tysiące osób
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Product 1: Olejek */}
            <Card className="overflow-hidden group hover:shadow-xl transition-shadow">
              <div className="relative h-64 bg-secondary overflow-hidden">
                <img
                  src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663192824179/cWCpmzwPukgLTNvN.png"
                  alt="Olejek Liptus"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-medium">
                  BESTSELLER
                </div>
              </div>
              <div className="p-6 space-y-4">
                <h3 className="text-2xl font-semibold">Olejek Liptus®</h3>
                <p className="text-muted-foreground">
                  Mieszanka 7 olejków eterycznych do inhalacji i dyfuzji. Świetna
                  alternatywa dla domowych inhalacji.
                </p>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold text-primary">
                    Od 35,99 zł
                  </span>
                </div>
                <Button
                  className="w-full"
                  onClick={() =>
                    window.open(
                      "https://klaudynahebda.pl/produkt/olejek-liptus/",
                      "_blank"
                    )
                  }
                >
                  Zobacz produkt
                </Button>
              </div>
            </Card>

            {/* Product 2: Roll-on */}
            <Card className="overflow-hidden group hover:shadow-xl transition-shadow">
              <div className="relative h-64 bg-secondary overflow-hidden">
                <img
                  src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663192824179/KfnZBKdpbBVYnjxn.png"
                  alt="Roll-on Liptus"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6 space-y-4">
                <h3 className="text-2xl font-semibold">Roll-on Liptus®</h3>
                <p className="text-muted-foreground">
                  Twój kieszonkowy wspólnik. Poręczny, dyskretny, skuteczny. Miej
                  go zawsze przy sobie.
                </p>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold text-primary">
                    49,00 zł
                  </span>
                </div>
                <Button
                  className="w-full"
                  onClick={() =>
                    window.open(
                      "https://klaudynahebda.pl/produkt/roll-on-liptus/",
                      "_blank"
                    )
                  }
                >
                  Zobacz produkt
                </Button>
              </div>
            </Card>

            {/* Product 3: Sól */}
            <Card className="overflow-hidden group hover:shadow-xl transition-shadow">
              <div className="relative h-64 bg-secondary overflow-hidden">
                <img
                  src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663192824179/TgkdtAhGJlaMXgIZ.png"
                  alt="Sól do kąpieli Liptus"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6 space-y-4">
                <h3 className="text-2xl font-semibold">Sól do kąpieli Liptus®</h3>
                <p className="text-muted-foreground">
                  Himalajska sól + 8 olejków eterycznych. Idealna po ciężkim dniu
                  dla odświeżenia ciała i umysłu.
                </p>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold text-primary">
                    69,00 zł
                  </span>
                </div>
                <Button
                  className="w-full"
                  onClick={() =>
                    window.open(
                      "https://klaudynahebda.pl/produkt/sol-do-kapieli-liptus/",
                      "_blank"
                    )
                  }
                >
                  Zobacz produkt
                </Button>
              </div>
            </Card>
          </div>

          <div className="text-center mt-12">
            <Button
              variant="outline"
              size="lg"
              onClick={() =>
                window.open(
                  "https://klaudynahebda.pl/sklep/seria-liptus/",
                  "_blank"
                )
              }
            >
              Zobacz wszystkie produkty Liptus®
            </Button>
          </div>
        </div>
      </section>

      {/* Educational Section: TRPM8 Effect */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl lg:text-5xl font-semibold mb-4">
                Efekt TRPM8 – dlaczego chłód przynosi ulgę?
              </h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                To nie magia – to nauka. Odkryj, jak eukaliptol i mentol z Liptus®
                aktywują naturalne receptory chłodu w Twoim organizmie.
              </p>
            </div>

            {/* Infographic */}
            <div className="mb-12">
              <AnimatedTRPM8 />
            </div>

            {/* Explanation */}
            <div className="grid md:grid-cols-3 gap-8">
              <Card className="p-6 bg-muted/30">
                <div className="text-center mb-4">
                  <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                    <span className="text-3xl">🧠</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">1. Receptory TRPM8</h3>
                </div>
                <p className="text-muted-foreground text-center">
                  W jamie nosowej znajdują się specjalne receptory TRPM8 –
                  naturalne "czujniki chłodu" w Twoim organizmie.
                </p>
              </Card>

              <Card className="p-6 bg-primary/10 border-primary">
                <div className="text-center mb-4">
                  <div className="w-16 h-16 mx-auto bg-primary/20 rounded-full flex items-center justify-center mb-4">
                    <Leaf className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2 text-primary">
                    2. Aktywacja
                  </h3>
                </div>
                <p className="text-center">
                  Eukaliptol i mentol z Liptus® łączą się z receptorami TRPM8,
                  aktywując je i wysyłając sygnał do mózgu.
                </p>
              </Card>

              <Card className="p-6 bg-muted/30">
                <div className="text-center mb-4">
                  <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                    <span className="text-3xl">❄️</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">3. Efekt Ulgi</h3>
                </div>
                <p className="text-muted-foreground text-center">
                  Mózg odbiera informację o chłodzie, co wywołuje uczucie
                  świeżości, ulgi i swobodnego oddychania.
                </p>
              </Card>
            </div>

            {/* Scientific note */}
            <div className="mt-12 text-center">
              <Card className="p-6 bg-secondary/50 inline-block">
                <p className="text-sm text-muted-foreground">
                  <strong className="text-foreground">Fakt naukowy:</strong>{" "}
                  Receptory TRPM8 są aktywowane przez temperatury poniżej 26°C
                  oraz przez związki chemiczne jak mentol i eukaliptol. To dlatego
                  Liptus® daje uczucie chłodu i świeżości – nawet bez zmiany
                  temperatury powietrza.
                </p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Storytelling Section - moved down */}
      <section className="py-20 bg-gradient-to-br from-secondary via-background to-secondary">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h2 className="text-4xl lg:text-5xl font-semibold">
              Weź głęboki oddech. Poczuj moc natury.
            </h2>

            <div className="grid md:grid-cols-2 gap-6 text-left">
              <Card className="p-6 bg-muted/30">
                <h3 className="text-xl font-semibold mb-3 text-muted-foreground">
                  Problemy, które znasz:
                </h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-destructive mt-1">✗</span>
                    <span>Uczucie zatkania nosa i zatok</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-destructive mt-1">✗</span>
                    <span>Szukasz naturalnego wsparcia bez chemii</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-destructive mt-1">✗</span>
                    <span>Chcesz rytuał, który naprawdę działa</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-destructive mt-1">✗</span>
                    <span>Potrzebujesz czegoś zawsze przy sobie</span>
                  </li>
                </ul>
              </Card>

              <Card className="p-6 bg-primary/10 border-primary">
                <h3 className="text-xl font-semibold mb-3 text-primary">
                  Rozwiązanie Liptus®:
                </h3>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">✓</span>
                    <span>7 olejków w synergicznej mieszance</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">✓</span>
                    <span>100% naturalne, bez syntetyków</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">✓</span>
                    <span>Receptura stworzona przez eksperta</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">✓</span>
                    <span>Różne formy - dla każdego coś</span>
                  </li>
                </ul>
              </Card>
            </div>

            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Liptus® to seria aromaterapeutyczna, która łączy eukaliptus, miętę,
              tymianek, cytrynę, oregano, kamforę i drzewo herbaciane w przemyślaną recepturę. To nie jest
              kolejny przypadkowy produkt – to wsparcie stworzone przez
              aromaterapeutkę kliniczną z 10-letnim doświadczeniem.
            </p>
          </div>
        </div>
      </section>

      {/* Educational Section: Synergia */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl lg:text-5xl font-semibold mb-4">
                Dlaczego synergia olejków ma znaczenie?
              </h2>
              <p className="text-lg text-muted-foreground">
                Połączenie kilku olejków eterycznych pozwala wydobyć z nich więcej niż z każdego z osobna. Starannie dobrane składniki wzajemnie się uzupełniają, dzięki czemu zapach jest pełniejszy, bardziej harmonijny i stabilny w czasie.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-12">
              <Card className="p-8 bg-muted/30">
                <h3 className="text-2xl font-semibold mb-4">
                  Pojedynczy olejek
                </h3>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="mt-1">•</span>
                    <span>Działa na jeden aspekt</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-1">•</span>
                    <span>Ograniczone spektrum korzyści</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-1">•</span>
                    <span>Może być za intensywny</span>
                  </li>
                </ul>
              </Card>

              <Card className="p-8 bg-primary/10 border-primary">
                <h3 className="text-2xl font-semibold mb-4 text-primary">
                  Mieszanka Liptus®
                </h3>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2">
                    <Leaf className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <span>7 olejków wzmacnia swoje działanie</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Leaf className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <span>Pełniejsze spektrum korzyści (efekt synergii)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Leaf className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <span>Zbalansowany, harmonijny aromat</span>
                  </li>
                </ul>
              </Card>
            </div>

            {/* Ingredients visual */}
            <div className="relative">
              <img
                src="https://private-us-east-1.manuscdn.com/sessionFile/6howxXJEJZBVnHYeBEpv5p/sandbox/aJ27DMArxBXaLtUTPdZ7Ll-img-4_1770213606000_na1fn_bGlwdHVzLWluZ3JlZGllbnRzLXN5bmVyZ3k.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNmhvd3hYSkVKWkJWbkhZZUJFcHY1cC9zYW5kYm94L2FKMjdETUFyeEJYYUx0VVRQZFo3TGwtaW1nLTRfMTc3MDIxMzYwNjAwMF9uYTFmbl9iR2x3ZEhWekxXbHVaM0psWkdsbGJuUnpMWE41Ym1WeVozay5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=naHHQ0e2ZxVkFug5B1ZWKs-7pQ2TOORm-d2osMWyEgF5CKcv0lTyi0CEvYhLQgMT65CWL5Xocnd16PyCgtxf92swCr2K1uPf7QW5pTW-EQ5dcWoK91~8Inz0WtsoY9iawfoID1yy7SK4Jmpvo8Qv540oKhMA098OaqLC-RNdX~Q6oPFXgRBc~7Z2~0GgVLMcjCD11jZy1iKaDt~mQLQBcac7VvWgdyzqoUQS4rUdqrvnhfqvG48ei~W7-HMDcqwTAUAhvl3brCf88SbI66HF5Z4QPpSIS6Gai6fLqp6bHKZTb0dWAD~hHN9gXKGLnGgKvFs~7rc7qe66RAW~hX8C5Q__"
                alt="Składniki Liptus"
                className="w-full rounded-2xl shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gradient-to-br from-secondary via-background to-secondary">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-5xl font-semibold mb-4">
              Co mówią nasi klienci?
            </h2>
            <p className="text-lg text-muted-foreground">
              Prawdziwe historie od prawdziwych ludzi
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Anna, 34 lata",
                quote:
                  "Ta sól uratowała moje wieczory! Wreszcie mogę normalnie zasnąć.",
                story:
                  "Po ciężkim dniu pracy kąpiel z Liptus® to mój sposób na reset. Zapach eukaliptusa i mięty pomaga mi się wyciszyć.",
              },
              {
                name: "Kasia, 28 lat",
                quote:
                  "Roll-on to mój must-have w torebce. Zawsze mam go przy sobie.",
                story:
                  "Pracuję w biurze i często czuję zmęczenie. Roll-on Liptus® to mój sposób na szybkie odświeżenie w ciągu dnia.",
              },
              {
                name: "Magda, 41 lat",
                quote:
                  "Dom pachnie jak spa. Goście zawsze pytają, co to za zapach.",
                story:
                  "Uwielbiam, jak mój dom pachnie po dyfuzji olejku Liptus®. To prawdziwa natura, nie sztuczny zapach.",
              },
            ].map((testimonial, index) => (
              <Card key={index} className="p-6 space-y-4">
                <div className="flex text-yellow-500 mb-2">
                  {"★★★★★".split("").map((star, i) => (
                    <span key={i}>{star}</span>
                  ))}
                </div>
                <p className="text-lg font-semibold italic">
                  "{testimonial.quote}"
                </p>
                <p className="text-muted-foreground">{testimonial.story}</p>
                <p className="text-sm font-medium text-primary">
                  — {testimonial.name}
                </p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Klaudyna Hebda Section */}
      <section className="py-20 bg-secondary/30">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              {/* Image */}
              <div className="relative">
                <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                  <img
                    src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663192824179/NBayrgtysRQhYsji.jpg"
                    alt="Klaudyna Hebda"
                    className="w-full h-auto object-cover"
                  />
                </div>
                {/* Decorative element */}
                <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-primary/10 rounded-full blur-3xl"></div>
              </div>

              {/* Bio */}
              <div className="space-y-6">
                <div className="inline-block px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-medium mb-2">
                  Twórczyni Liptus®
                </div>
                <h2 className="text-4xl lg:text-5xl font-semibold">
                  Poznaj Klaudynę Hebdę
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  <strong className="text-foreground">Pionierka aromaterapii klinicznej w Polsce</strong>, zielarka, fitoterapeutka.
                </p>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Od dzieciństwa zafascynowana światem roślin. W 2015 roku założyła markę <strong className="text-foreground">Klaudyna Hebda Nature</strong>. Wcześniej dzieliła się wiedzą na blogu <em>Ziołowy Zakątek</em> - zawsze z sercem i pasją. Tak też nazwała swoją książkę.
                </p>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Tworzy autorskie receptury, inwestuje w badania naukowe, m.in. o właściwościach oregano. Od lat udowadnia, że <strong className="text-foreground">aromaterapia to nie tylko piękne zapachy, ale realne wsparcie</strong>.
                </p>
                <div className="flex flex-wrap gap-4 pt-4">
                  <div className="flex items-center gap-2 text-primary">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                    <span className="font-medium">Pionierka w Polsce</span>
                  </div>
                  <div className="flex items-center gap-2 text-primary">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z" />
                    </svg>
                    <span className="font-medium">Badania naukowe</span>
                  </div>
                  <div className="flex items-center gap-2 text-primary">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span className="font-medium">Autorskie receptury</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl lg:text-5xl font-semibold mb-4">
                Najczęściej zadawane pytania
              </h2>
              <p className="text-lg text-muted-foreground">
                Wszystko, co musisz wiedzieć o Liptus®
              </p>
            </div>

            <div className="space-y-4">
              {/* FAQ 1 */}
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-semibold mb-3 text-primary">
                  Jak stosować produkty Liptus®?
                </h3>
                <p className="text-muted-foreground">
                  <strong>Olejek:</strong> Dodaj 2-3 krople do dyfuzora lub
                  inhalatora. Możesz też użyć do inhalacji parowej (5-6 kropli na
                  miskę gorącej wody). <br />
                  <strong>Roll-on:</strong> Aplikuj na skronie, kark lub pod nos.
                  Możesz używać wielokrotnie w ciągu dnia. <br />
                  <strong>Sól do kąpieli:</strong> Rozpuszczaj 2-3 łyżki w ciepłej
                  wodzie. Kąpiel trwa 15-20 minut.
                </p>
              </Card>

              {/* FAQ 2 */}
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-semibold mb-3 text-primary">
                  Czy Liptus® jest bezpieczny dla dzieci?
                </h3>
                <p className="text-muted-foreground">
                  Produkty Liptus® są bezpieczne dla dzieci <strong>powyżej 3. roku
                  życia</strong> w odpowiednim stężeniu. Dla dzieci zalecamy
                  rozcieńczenie olejku (1 kropla na dyfuzor) lub stosowanie soli do
                  kąpieli pod nadzorem dorosłych. Roll-on można stosować u dzieci
                  powyżej 6 lat. <strong>Nie stosuj u niemowląt i kobiet w
                  ciąży</strong> bez konsultacji z lekarzem.
                </p>
              </Card>

              {/* FAQ 3 */}
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-semibold mb-3 text-primary">
                  Jak długo starczy jeden produkt?
                </h3>
                <p className="text-muted-foreground">
                  <strong>Olejek 10ml:</strong> Przy codziennym użyciu (2-3 krople
                  dziennie) starczy na ok. 2-3 miesiące. <br />
                  <strong>Roll-on 10ml:</strong> Przy regularnym stosowaniu (3-4 razy
                  dziennie) starczy na ok. 4-6 tygodni. <br />
                  <strong>Sól 500g:</strong> Wystarczy na 8-12 kąpieli (w zależności od
                  ilości używanej soli).
                </p>
              </Card>

              {/* FAQ 4 */}
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-semibold mb-3 text-primary">
                  Czy mogę używać Liptus® codziennie?
                </h3>
                <p className="text-muted-foreground">
                  Tak! Produkty Liptus® są stworzone z naturalnych składników i można
                  je stosować codziennie. Wiele osób włącza je do swojego porannego
                  lub wieczornego rytuąłu. Jeśli masz skórę wrażliwą, zacznij od
                  mniejszych stężeń i obserwuj reakcję organizmu.
                </p>
              </Card>

              {/* FAQ 5 */}
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-semibold mb-3 text-primary">
                  Jak szybko zauważę efekty?
                </h3>
                <p className="text-muted-foreground">
                  Efekt <strong>świeżości i ulgi</strong> odczujesz natychmiast
                  dzięki aktywacji receptorów TRPM8. Długoterminowe korzyści (lepszy
                  sen, redukcja stresu, poprawa samopoczucia) są zazwyczaj widoczne
                  po <strong>7-14 dniach regularnego stosowania</strong>. Każdy
                  organizm reaguje indywidualnie.
                </p>
              </Card>

              {/* FAQ 6 */}
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-semibold mb-3 text-primary">
                  Czy produkty są 100% naturalne?
                </h3>
                <p className="text-muted-foreground">
                  Tak! Wszystkie produkty Liptus® zawierają{" "}
                  <strong>100% naturalne olejki eteryczne</strong> bez dodatku
                  syntetycznych zapachów, parabenu czy sztucznych barwników. Sól do
                  kąpieli oparta jest na naturalnej soli himalajskiej. Produkty są
                  ręcznie wytwarzane w małych partiach przez aromaterapeutkę kliniczną.
                </p>
              </Card>

              {/* FAQ 7 */}
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-semibold mb-3 text-primary">
                  Co jeśli produkt mi nie odpowiada?
                </h3>
                <p className="text-muted-foreground">
                  Oferujemy <strong>30-dniową gwarancję satysfakcji</strong>. Jeśli z
                  jakiegokolwiek powodu produkt Ci nie odpowiada, skontaktuj się z
                  nami przez formularz kontaktowy, a zwrócimy Ci pieniądze bez
                  zbędnych pytań. Twoja satysfakcja jest dla nas najważniejsza.
                </p>
              </Card>

              {/* FAQ 8 */}
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-semibold mb-3 text-primary">
                  Jak przechwywać produkty Liptus®?
                </h3>
                <p className="text-muted-foreground">
                  Olejki eteryczne najlepiej przechowywać w{" "}
                  <strong>ciemnym, chłodnym miejscu</strong>, z dala od
                  bezpośredniego słońca (np. szafka w łazience). Butelki powinny być
                  szczelnie zamknięte. Roll-on możesz nosić ze sobą w torebce. Sól do
                  kąpieli przechowuj w suchym miejscu w zamkniętym pojemniku. Trwałość:
                  2 lata od daty produkcji.
                </p>
              </Card>
            </div>

            {/* CTA after FAQ */}
            <div className="text-center mt-12">
              <p className="text-muted-foreground mb-6">
                Masz inne pytanie? Skontaktuj się z nami!
              </p>
              <Button
                variant="outline"
                size="lg"
                onClick={() =>
                  window.open("https://klaudynahebda.pl/kontakt/", "_blank")
                }
              >
                Zadaj pytanie
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-br from-primary/10 via-secondary to-primary/10">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            <h2 className="text-4xl lg:text-5xl font-semibold">
              Jaki rytuał Liptus® jest dla Ciebie?
            </h2>
            <p className="text-lg text-muted-foreground">
              Nie zgaduj - dowiedz się, który produkt Liptus® jest stworzony
              właśnie dla Ciebie. Wypełnij quiz i otrzymaj spersonalizowane
              rekomendacje + zniżkę 15%.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={handleQuizOpen}
                className="text-lg"
              >
                Rozpocznij quiz teraz
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() =>
                  window.open(
                    "https://klaudynahebda.pl/sklep/seria-liptus/",
                    "_blank"
                  )
                }
                className="text-lg"
              >
                Zobacz wszystkie produkty
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-semibold text-lg mb-4">O Nas</h3>
              <ul className="space-y-2 text-sm opacity-80">
                <li>
                  <a
                    href="https://klaudynahebda.pl/o-nas/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:opacity-100"
                  >
                    O Klaudynie Hebdzie
                  </a>
                </li>
                <li>
                  <a
                    href="https://klaudynahebda.pl/kontakt/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:opacity-100"
                  >
                    Kontakt
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-lg mb-4">Produkty</h3>
              <ul className="space-y-2 text-sm opacity-80">
                <li>
                  <a
                    href="https://klaudynahebda.pl/sklep/seria-liptus/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:opacity-100"
                  >
                    Seria Liptus®
                  </a>
                </li>
                <li>
                  <a
                    href="https://klaudynahebda.pl/sklep/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:opacity-100"
                  >
                    Wszystkie Produkty
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-lg mb-4">Wsparcie</h3>
              <ul className="space-y-2 text-sm opacity-80">
                <li>
                  <a
                    href="https://klaudynahebda.pl/regulamin/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:opacity-100"
                  >
                    Regulamin
                  </a>
                </li>
                <li>
                  <a
                    href="https://klaudynahebda.pl/polityka-prywatnosci/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:opacity-100"
                  >
                    Polityka Prywatności
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-lg mb-4">Społeczność</h3>
              <ul className="space-y-2 text-sm opacity-80">
                <li>
                  <a
                    href="https://www.facebook.com/klaudynahebdanature"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:opacity-100"
                  >
                    Facebook
                  </a>
                </li>
                <li>
                  <a
                    href="https://www.instagram.com/klaudyna_hebda_nature/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:opacity-100"
                  >
                    Instagram
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-background/20 pt-8 text-center text-sm opacity-60">
            <p>© 2026 Klaudyna Hebda Nature. Wszelkie prawa zastrzeżone.</p>
          </div>
        </div>
      </footer>

      {/* Quiz Funnel Modal */}
      <QuizFunnel isOpen={isQuizOpen} onClose={() => setIsQuizOpen(false)} />
    </div>
  );
}
