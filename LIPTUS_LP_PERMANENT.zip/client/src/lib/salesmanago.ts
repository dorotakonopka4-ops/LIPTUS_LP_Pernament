/**
 * SALESmanago tracking helper
 * Provides type-safe wrapper for sm() calls (SALESmanago monitoring code)
 */

declare global {
  interface Window {
    sm?: (...args: any[]) => void;
    _smid?: string;
  }
}

/**
 * Identify user in SALESmanago (smclient)
 * Call this after user provides email in quiz
 * @param email - User email address
 * @param name - Optional user name
 */
export function identifySalesmanagoUser(email: string, name?: string) {
  if (typeof window !== "undefined" && window.sm) {
    try {
      window.sm("identify", {
        email,
        ...(name && { name }),
      });
      console.log(`[SALESmanago] Identified user: ${email}`);
    } catch (error) {
      console.error(`[SALESmanago] Error identifying user:`, error);
    }
  } else {
    console.warn("[SALESmanago] sm() not available");
  }
}

/**
 * Track custom event in SALESmanago
 * @param eventName - Event name
 * @param params - Optional event parameters
 */
export function trackSalesmanagoEvent(eventName: string, params?: Record<string, any>) {
  if (typeof window !== "undefined" && window.sm) {
    try {
      window.sm("event", eventName, params);
      console.log(`[SALESmanago] Tracked event: ${eventName}`, params);
    } catch (error) {
      console.error(`[SALESmanago] Error tracking event:`, error);
    }
  } else {
    console.warn("[SALESmanago] sm() not available");
  }
}
