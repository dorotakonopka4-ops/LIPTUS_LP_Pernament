/**
 * Facebook Pixel tracking helper
 * Provides type-safe wrapper for fbq() calls
 */

declare global {
  interface Window {
    fbq?: (action: string, eventName: string, params?: Record<string, any>) => void;
  }
}

/**
 * Track Facebook Pixel event
 * @param eventName - Standard or custom event name
 * @param params - Optional event parameters
 */
export function trackFBEvent(eventName: string, params?: Record<string, any>) {
  if (typeof window !== "undefined" && window.fbq) {
    try {
      window.fbq("track", eventName, params);
      console.log(`[FB Pixel] Tracked: ${eventName}`, params);
    } catch (error) {
      console.error(`[FB Pixel] Error tracking ${eventName}:`, error);
    }
  } else {
    console.warn("[FB Pixel] fbq not available");
  }
}

/**
 * Track custom Facebook Pixel event
 * @param eventName - Custom event name
 * @param params - Optional event parameters
 */
export function trackFBCustomEvent(eventName: string, params?: Record<string, any>) {
  if (typeof window !== "undefined" && window.fbq) {
    try {
      window.fbq("trackCustom", eventName, params);
      console.log(`[FB Pixel] Tracked custom: ${eventName}`, params);
    } catch (error) {
      console.error(`[FB Pixel] Error tracking custom ${eventName}:`, error);
    }
  } else {
    console.warn("[FB Pixel] fbq not available");
  }
}

/**
 * Standard Facebook Pixel events
 */
export const FBEvents = {
  // Standard events
  VIEW_CONTENT: "ViewContent",
  SEARCH: "Search",
  ADD_TO_CART: "AddToCart",
  ADD_TO_WISHLIST: "AddToWishlist",
  INITIATE_CHECKOUT: "InitiateCheckout",
  ADD_PAYMENT_INFO: "AddPaymentInfo",
  PURCHASE: "Purchase",
  LEAD: "Lead",
  COMPLETE_REGISTRATION: "CompleteRegistration",
  
  // Custom events for Liptus
  QUIZ_STARTED: "QuizStarted",
  QUIZ_STEP_COMPLETED: "QuizStepCompleted",
  QUIZ_COMPLETED: "QuizCompleted",
  PRODUCT_RECOMMENDATION_VIEWED: "ProductRecommendationViewed",
} as const;
