/**
 * Google Tag Manager tracking helper
 * Provides type-safe wrapper for dataLayer.push() calls
 * GTM will handle Facebook Pixel, Google Analytics, and other tags
 */

declare global {
  interface Window {
    dataLayer?: any[];
  }
}

/**
 * Push event to GTM dataLayer
 * @param eventName - Event name
 * @param params - Optional event parameters
 */
export function trackGTMEvent(eventName: string, params?: Record<string, any>) {
  if (typeof window !== "undefined") {
    try {
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        event: eventName,
        ...params,
      });
      console.log(`[GTM] Tracked: ${eventName}`, params);
    } catch (error) {
      console.error(`[GTM] Error tracking ${eventName}:`, error);
    }
  } else {
    console.warn("[GTM] dataLayer not available (SSR)");
  }
}

/**
 * Standard events for Liptus® tracking
 * These will be picked up by GTM and forwarded to Facebook Pixel, GA, etc.
 */
export const GTMEvents = {
  // Standard e-commerce events
  VIEW_CONTENT: "view_content",
  SEARCH: "search",
  ADD_TO_CART: "add_to_cart",
  ADD_TO_WISHLIST: "add_to_wishlist",
  INITIATE_CHECKOUT: "begin_checkout",
  ADD_PAYMENT_INFO: "add_payment_info",
  PURCHASE: "purchase",
  LEAD: "generate_lead",
  COMPLETE_REGISTRATION: "sign_up",
  
  // Custom events for Liptus® quiz funnel
  QUIZ_STARTED: "quiz_started",
  QUIZ_STEP_COMPLETED: "quiz_step_completed",
  QUIZ_COMPLETED: "quiz_completed",
  PRODUCT_RECOMMENDATION_VIEWED: "product_recommendation_viewed",
} as const;
