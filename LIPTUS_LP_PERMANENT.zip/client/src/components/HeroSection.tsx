/**
 * Modern Apothecary Design: Asymmetric hero with large lifestyle image + breathing space
 * Color: Sage Green + Warm Cream + Deep Forest
 * Typography: Playfair Display (headlines) + Inter (body)
 */

import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";

interface HeroSectionProps {
  onQuizClick: () => void;
}

export default function HeroSection({ onQuizClick }: HeroSectionProps) {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-gradient-to-br from-background via-secondary to-background">
      {/* Decorative eucalyptus background */}
      <div className="absolute inset-0 opacity-30">
        <img
          src="https://private-us-east-1.manuscdn.com/sessionFile/6howxXJEJZBVnHYeBEpv5p/sandbox/aJ27DMArxBXaLtUTPdZ7Ll-img-1_1770213600000_na1fn_bGlwdHVzLWhlcm8tZXVjYWx5cHR1cw.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNmhvd3hYSkVKWkJWbkhZZUJFcHY1cC9zYW5kYm94L2FKMjdETUFyeEJYYUx0VVRQZFo3TGwtaW1nLTFfMTc3MDIxMzYwMDAwMF9uYTFmbl9iR2x3ZEhWekxXaGxjbTh0WlhWallXeDVjSFIxY3cucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=RMHbVc35B3ymZzk3xP92UqurnTBnKswmBh8Iia1LELA03s0l1dVrqLW8p7rPA-JwiorPKJMebUOUbijDDX1J~eICQoHv1hAYu~huEkF649wBdOCCJgVy0QJzrQLkn3J9~0AhC2vUPNA9MG1fahv1VTKGk5feAmSVl41tNhDoWf5X6rlY5mwE-yvkaypl896V00KXPJssA6WV8rhdDXnFO8GZsfIIqsAy3UMvJO9rbxcP~X2LB-fl-JNbO~QcI5ahnoJP58GafJDPTOnNaTolai5yqJ5WJ1Xu-U6WfVQ9xyqbk31P-dI-VZfxbIip0DMt9Lv7~VAW11~IDOiurWpP3w__"
          alt="Dekoracyjne tło z gałązkami eukaliptusa"
          className="w-full h-full object-cover"
        />
      </div>

      <div className="container relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left: Content */}
          <div className="space-y-8 animate-fade-in">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full border border-primary/20">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">
                15,908 zadowolonych klientów ★★★★★
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-5xl lg:text-6xl xl:text-7xl font-semibold leading-tight text-foreground">
              Weź głęboki oddech.{" "}
              <span className="text-primary">Poczuj moc natury.</span>
            </h1>

            {/* Subheadline */}
            <p className="text-lg lg:text-xl text-muted-foreground leading-relaxed max-w-xl">
              Odkryj autorską serię Liptus® – stworzoną przez aromaterapeutkę
              kliniczną z 10-letnim doświadczeniem, Klaudynę Hebdę. Połączyliśmy
              tradycyjną moc ziół z nowoczesnymi recepturami, by dać Ci komfort
              swobodnego oddechu i regenerację, na jaką zasługujesz.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                onClick={onQuizClick}
                className="text-base group animate-breathe"
              >
                Poznaj swój  rytuał oddechu
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => {
                  document
                    .getElementById("products")
                    ?.scrollIntoView({ behavior: "smooth" });
                }}
                className="text-base"
              >
                Poznaj serię Liptus®
              </Button>
            </div>

            {/* Trust elements */}
            <div className="flex flex-wrap gap-6 pt-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <svg
                  className="w-5 h-5 text-primary"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
                <span>100% naturalne składniki</span>
              </div>
              <div className="flex items-center gap-2">
                <svg
                  className="w-5 h-5 text-primary"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
                <span>Darmowa dostawa od 199 zł</span>
              </div>
              <div className="flex items-center gap-2">
                <svg
                  className="w-5 h-5 text-primary"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
                <span>Szybka wysyłka w 24h</span>
              </div>
            </div>
          </div>

          {/* Right: Image */}
          <div className="relative lg:block hidden">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <img
                src="https://private-us-east-1.manuscdn.com/sessionFile/6howxXJEJZBVnHYeBEpv5p/sandbox/TPhsWq9ge6JxWEYLamR89H-img-1_1770301404000_na1fn_bGlwdHVzLWxpZmVzdHlsZS1icmVhdGhpbmctcHJvZHVjdA.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNmhvd3hYSkVKWkJWbkhZZUJFcHY1cC9zYW5kYm94L1RQaHNXcTlnZTZKeFdFWUxhbVI4OUgtaW1nLTFfMTc3MDMwMTQwNDAwMF9uYTFmbl9iR2x3ZEhWekxXeHBabVZ6ZEhsc1pTMWljbVZoZEdocGJtY3RjSEp2WkhWamRBLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=V7dUl336~C6S3-Zjn4zaYDAkAWljjVKdrN5JJ38dZUtR6wgmGHaSFS3FAT4Olbcro78cS89YQjQHuPpeOdgSH~mWoyRYguF0MuZfGCrVnTwUE01BwelI932BLnHeCaMn27BksFw~T4LfudGosCR0LfCf548NK86XEkGtziZBqFpb7t2aiVqqhByOpRtVQczNrBWmwA-CCzvrstq9T~Al4gA0HTSOVd1BSbgDAUO2SIsMF5cTfY9bBEKQyn6XV2dGQmoavX0xbB6WZeIbaQy2QYaminwbTzR2XKOWF2x23Qobt-d1HhUCUsVRi9UkmUeST6x1EqJxPxrjjczV78D8dQ__"
                alt="Kobieta wdychająca świeżość eukaliptusa - głęboki oddech"
                className="w-full h-auto"
              />
              {/* Floating badge */}
              <div className="absolute bottom-6 left-6 bg-card/95 backdrop-blur-sm px-6 py-4 rounded-2xl shadow-lg">
                <p className="text-sm text-muted-foreground mb-1">
                  Ocena klientów
                </p>
                <div className="flex items-center gap-2">
                  <span className="text-3xl font-bold text-foreground">
                    5.0
                  </span>
                  <div className="flex text-yellow-500">
                    {"★★★★★".split("").map((star, i) => (
                      <span key={i}>{star}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
