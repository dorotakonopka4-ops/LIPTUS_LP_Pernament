/**
 * Animated TRPM8 Mechanism Diagram
 * Shows how eucalyptol and menthol interact with TRPM8 receptors
 * Uses Framer Motion for smooth animations
 */

import { motion, useInView } from "framer-motion";
import { useRef } from "react";

export default function AnimatedTRPM8() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <div ref={ref} className="relative w-full">
      {/* Base image */}
      <img
        src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663192824179/ZakikjCcBnmQpIFC.png"
        alt="Mechanizm TRPM8 - Jak działa Liptus"
        className="w-full rounded-2xl shadow-lg"
      />

      {/* Animated overlays */}
      {isInView && (
        <>
          {/* Step 1: Floating molecules (eucalyptol & menthol) - flowing towards nose */}
          <motion.div
            className="absolute top-[50%] left-[30%] w-8 h-8 bg-blue-400/30 rounded-full border-2 border-blue-500"
            initial={{ opacity: 0, x: 40, y: 30 }}
            animate={{
              opacity: [0, 1, 1, 0],
              x: [40, 20, 0, -20],
              y: [30, 15, 5, -10],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              repeatDelay: 1,
              ease: "easeInOut",
            }}
          />
          <motion.div
            className="absolute top-[55%] left-[32%] w-6 h-6 bg-green-400/30 rounded-full border-2 border-green-500"
            initial={{ opacity: 0, x: 35, y: 25 }}
            animate={{
              opacity: [0, 1, 1, 0],
              x: [35, 18, 5, -15],
              y: [25, 12, 3, -8],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              repeatDelay: 1,
              delay: 0.5,
              ease: "easeInOut",
            }}
          />

          {/* Step 2: Receptor activation (pulsing effect) */}
          <motion.div
            className="absolute top-[42%] left-[47%] w-12 h-16 bg-blue-500/20 rounded-lg"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{
              opacity: [0, 0.3, 0.5, 0.3, 0],
              scale: [0.8, 1, 1.1, 1, 0.8],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              repeatDelay: 2,
              delay: 2,
              ease: "easeInOut",
            }}
          />

          {/* Step 3: Neural signal arrows */}
          <motion.div
            className="absolute top-[45%] left-[60%] w-20 h-1 bg-gradient-to-r from-blue-500 to-transparent"
            initial={{ opacity: 0, scaleX: 0 }}
            animate={{
              opacity: [0, 1, 1, 0],
              scaleX: [0, 1, 1, 0],
            }}
            style={{ transformOrigin: "left" }}
            transition={{
              duration: 2,
              repeat: Infinity,
              repeatDelay: 3,
              delay: 3,
              ease: "easeOut",
            }}
          />
          <motion.div
            className="absolute top-[43%] left-[62%] w-16 h-1 bg-gradient-to-r from-green-500 to-transparent"
            initial={{ opacity: 0, scaleX: 0 }}
            animate={{
              opacity: [0, 1, 1, 0],
              scaleX: [0, 1, 1, 0],
            }}
            style={{ transformOrigin: "left" }}
            transition={{
              duration: 2,
              repeat: Infinity,
              repeatDelay: 3,
              delay: 3.3,
              ease: "easeOut",
            }}
          />

          {/* Step 3: Effect icons animation */}
          {/* Snowflake (freshness) */}
          <motion.div
            className="absolute top-[25%] right-[18%] text-blue-500"
            initial={{ opacity: 0, scale: 0, rotate: 0 }}
            animate={{
              opacity: [0, 1, 1],
              scale: [0, 1.2, 1],
              rotate: [0, 180, 360],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              repeatDelay: 3.5,
              delay: 4,
              ease: "easeOut",
            }}
          >
            <svg
              className="w-8 h-8"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M12 2L10 8L4 6L8 10L2 12L8 14L6 20L10 16L12 22L14 16L18 20L16 14L22 12L16 10L20 6L14 8L12 2Z" />
            </svg>
          </motion.div>

          {/* Wind (easy breathing) */}
          <motion.div
            className="absolute top-[70%] right-[15%] text-blue-400"
            initial={{ opacity: 0, x: -10 }}
            animate={{
              opacity: [0, 1, 1, 0],
              x: [-10, 0, 10, 20],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              repeatDelay: 3,
              delay: 5,
              ease: "easeInOut",
            }}
          >
            <svg
              className="w-10 h-10"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M9 10h6M9 14h6M9 18h3" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </motion.div>
        </>
      )}
    </div>
  );
}
