/**
 * Countdown Timer Component - Creates urgency for promotional offers
 * Counts down to end of day (midnight) or a specific date
 */

import { useEffect, useState } from "react";

interface CountdownTimerProps {
  targetDate?: Date;
  endOfDay?: boolean;
  onExpire?: () => void;
}

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export default function CountdownTimer({
  targetDate,
  endOfDay = true,
  onExpire,
}: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const calculateTimeLeft = (): TimeLeft => {
      let target: Date;

      if (targetDate) {
        target = targetDate;
      } else if (endOfDay) {
        // End of today (midnight)
        target = new Date();
        target.setHours(23, 59, 59, 999);
      } else {
        // Default: 24 hours from now
        target = new Date(Date.now() + 24 * 60 * 60 * 1000);
      }

      const difference = target.getTime() - Date.now();

      if (difference <= 0) {
        onExpire?.();
        return { days: 0, hours: 0, minutes: 0, seconds: 0 };
      }

      return {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    };

    // Initial calculation
    setTimeLeft(calculateTimeLeft());

    // Update every second
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(timer);
  }, [targetDate, endOfDay, onExpire]);

  const formatNumber = (num: number): string => {
    return num.toString().padStart(2, "0");
  };

  return (
    <div className="flex items-center justify-center gap-2 sm:gap-4">
      {timeLeft.days > 0 && (
        <>
          <TimeUnit value={timeLeft.days} label="Dni" />
          <Separator />
        </>
      )}
      <TimeUnit value={timeLeft.hours} label="Godz" />
      <Separator />
      <TimeUnit value={timeLeft.minutes} label="Min" />
      <Separator />
      <TimeUnit value={timeLeft.seconds} label="Sek" />
    </div>
  );
}

function TimeUnit({ value, label }: { value: number; label: string }) {
  const formatNumber = (num: number): string => {
    return num.toString().padStart(2, "0");
  };

  return (
    <div className="flex flex-col items-center">
      <div className="bg-primary text-primary-foreground rounded-lg px-3 py-2 sm:px-4 sm:py-3 min-w-[60px] sm:min-w-[80px]">
        <span className="text-2xl sm:text-4xl font-bold tabular-nums">
          {formatNumber(value)}
        </span>
      </div>
      <span className="text-xs sm:text-sm text-muted-foreground mt-1 font-medium">
        {label}
      </span>
    </div>
  );
}

function Separator() {
  return (
    <div className="text-2xl sm:text-4xl font-bold text-primary pb-6">:</div>
  );
}
