/**
 * Quiz-First Hero Section - Version B for A/B testing
 * Immediate engagement with quiz CTA instead of storytelling
 */

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import CountdownTimer from "@/components/CountdownTimer";
import { ArrowRight, Sparkles, Clock, CheckCircle } from "lucide-react";

interface QuizHeroProps {
  onQuizClick: () => void;
}

export default function QuizHero({ onQuizClick }: QuizHeroProps) {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-gradient-to-br from-primary/5 via-secondary to-primary/10">
      {/* Decorative background */}
      <div className="absolute inset-0 opacity-20">
        <img
          src="https://private-us-east-1.manuscdn.com/sessionFile/6howxXJEJZBVnHYeBEpv5p/sandbox/aJ27DMArxBXaLtUTPdZ7Ll-img-1_1770213600000_na1fn_bGlwdHVzLWhlcm8tZXVjYWx5cHR1cw.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNmhvd3hYSkVKWkJWbkhZZUJFcHY1cC9zYW5kYm94L2FKMjdETUFyeEJYYUx0VVRQZFo3TGwtaW1nLTFfMTc3MDIxMzYwMDAwMF9uYTFmbl9iR2x3ZEhWekxXaGxjbTh0WlhWallXeDVjSFIxY3cucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=RMHbVc35B3ymZzk3xP92UqurnTBnKswmBh8Iia1LELA03s0l1dVrqLW8p7rPA-JwiorPKJMebUOUbijDDX1J~eICQoHv1hAYu~huEkF649wBdOCCJgVy0QJzrQLkn3J9~0AhC2vUPNA9MG1fahv1VTKGk5feAmSVl41tNhDoWf5X6rlY5mwE-yvkaypl896V00KXPJssA6WV8rhdDXnFO8GZsfIIqsAy3UMvJO9rbxcP~X2LB-fl-JNbO~QcI5ahnoJP58GafJDPTOnNaTolai5yqJ5WJ1Xu-U6WfVQ9xyqbk31P-dI-VZfxbIip0DMt9Lv7~VAW11~IDOiurWpP3w__"
          alt="Dekoracyjne tło z gałązkami eukaliptusa"
          className="w-full h-full object-cover"
        />
      </div>

      <div className="container relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Main Quiz Card */}
          <Card className="p-8 md:p-12 bg-card/95 backdrop-blur-sm shadow-2xl border-2 border-primary/20">
            {/* Badge */}
            <div className="flex justify-center mb-6">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full border border-primary/20">
                <Sparkles className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-primary">
                  15,908 osób znalazło swój idealny rytuał ★★★★★
                </span>
              </div>
            </div>

            {/* Main Headline */}
            <div className="text-center space-y-4 mb-8">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-semibold leading-tight">
                Który produkt Liptus®{" "}
                <span className="text-primary">jest stworzony dla Ciebie?</span>
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
                Odpowiedz na 5 prostych pytań, a my dopasujemy idealne produkty
                do Twoich potrzeb. Zajmie Ci to tylko 2 minuty.
              </p>
            </div>

            {/* Benefits */}
            <div className="grid md:grid-cols-3 gap-4 mb-8">
              <div className="flex items-start gap-3 p-4 bg-secondary/50 rounded-lg">
                <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-sm mb-1">
                    Spersonalizowane rekomendacje
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Nie zgaduj - dowiedz się, co naprawdę Ci pomoże
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 bg-secondary/50 rounded-lg">
                <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-sm mb-1">Porady od eksperta</p>
                  <p className="text-xs text-muted-foreground">
                    Receptury stworzone przez aromaterapeutkę
                  </p>
                </div>
              </div>
            </div>

            {/* Countdown Timer */}
            <Card className="p-6 bg-destructive/5 border-destructive/30 mb-8">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Clock className="w-5 h-5 text-destructive" />
                <p className="text-sm font-semibold text-destructive">
                  ⚡ Oferta specjalna wygasa za:
                </p>
              </div>
              <CountdownTimer endOfDay={true} />
              <p className="text-xs text-center text-muted-foreground mt-4">
                Nie przegap! Zniżka 15% dostępna tylko dziś.
              </p>
            </Card>

            {/* CTA Button */}
            <div className="text-center space-y-4">
              <Button
                size="lg"
                onClick={onQuizClick}
                className="text-xl px-12 py-8 h-auto w-full md:w-auto group animate-breathe shadow-lg"
              >
                Rozpocznij quiz (2 minuty)
                <ArrowRight className="ml-3 w-6 h-6 group-hover:translate-x-1 transition-transform" />
              </Button>

              <p className="text-sm text-muted-foreground">
                ✓ Bezpłatny quiz ✓ Bez zobowiązań ✓ Natychmiastowe wyniki
              </p>
            </div>
          </Card>

          {/* Trust indicators below */}
          <div className="mt-8 flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <svg
                className="w-5 h-5 text-primary"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
              <span>100% naturalne składniki</span>
            </div>
            <div className="flex items-center gap-2">
              <svg
                className="w-5 h-5 text-primary"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
              <span>Darmowa dostawa od 199 zł</span>
            </div>
            <div className="flex items-center gap-2">
              <svg
                className="w-5 h-5 text-primary"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
              <span>Szybka wysyłka w 24h</span>
            </div>
          </div>

          {/* Small storytelling teaser */}
          <div className="mt-12 text-center">
            <p className="text-muted-foreground text-sm">
              Odkryj autorską serię stworzoną przez{" "}
              <span className="font-semibold text-foreground">
                Klaudynę Hebdę
              </span>
              , aromaterapeutkę kliniczną z 10-letnim doświadczeniem
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
