/**
 * Quiz Funnel Component - Interactive product finder
 * Based on LUXGROVE analysis + Liptus strategy
 */

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import CountdownTimer from "@/components/CountdownTimer";
import { X, ArrowLeft, ArrowRight, Clock } from "lucide-react";
import { trackABTestEvent } from "@/lib/abtest";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { trackGTMEvent, GTMEvents } from "@/lib/gtm";
import { identifySalesmanagoUser, trackSalesmanagoEvent } from "@/lib/salesmanago";

interface QuizFunnelProps {
  isOpen: boolean;
  onClose: () => void;
}

interface QuizAnswer {
  questionId: number;
  answer: string;
}

const QUIZ_QUESTIONS = [
  {
    id: 1,
    question: "Jaki jest Twój główny cel na dziś?",
    subtitle: "Pomóż nam zrozumieć, czego potrzebujesz",
    options: [
      { value: "breath", label: "🍃 Swobodny Oddech", icon: "🍃" },
      { value: "relax", label: "🌙 Głęboki Relaks i Sen", icon: "🌙" },
      { value: "atmosphere", label: "🏠 Stworzenie Atmosfery w Domu", icon: "🏠" },
      { value: "support", label: "⚡ Szybkie Wsparcie w Ciągu Dnia", icon: "⚡" },
    ],
  },
  {
    id: 2,
    question: "Gdzie i kiedy będziesz potrzebować wsparcia?",
    subtitle: "Kontekst użycia pomoże nam dopasować produkt",
    options: [
      { value: "home", label: "W domowym zaciszu, po ciężkim dniu" },
      { value: "work", label: "W pracy lub w podróży" },
      { value: "illness", label: "Podczas choroby lub przeziębienia" },
      { value: "daily", label: "Jako element codziennej pielęgnacji" },
    ],
  },
  {
    id: 3,
    question: "Co pozwala Ci naprawdę odetchnąć?",
    subtitle: "Wybierz swój ulubiony sposób relaksu",
    options: [
      { value: "bath", label: "🛁 Długa, gorąca kąpiel" },
      { value: "massage", label: "💆‍♀️ Kojący masaż" },
      { value: "diffusion", label: "💨 Dyfuzowanie olejków eterycznych" },
      { value: "tea", label: "☕ Ciepły kubek ziołowej herbaty" },
    ],
  },
  {
    id: 4,
    question: "Jak intensywne aromaty lubisz?",
    subtitle: "Pomożemy dopasować intensywność zapachu",
    options: [
      { value: "subtle", label: "Subtelne i delikatne" },
      { value: "moderate", label: "Wyraźne i orzeźwiające" },
      { value: "intense", label: "Intensywne i mocne" },
    ],
  },
  {
    id: 5,
    question: "Co przekonałoby Cię do wypróbowania Liptus®?",
    subtitle: "Twoja opinia jest dla nas ważna",
    options: [
      { value: "proof", label: "Potwierdzona skuteczność (opinie, badania)" },
      { value: "simplicity", label: "Prostota i szybkość użycia" },
      { value: "guarantee", label: "Gwarancja satysfakcji lub zwrot pieniędzy" },
      { value: "natural", label: "Naturalny, bezpieczny skład" },
    ],
  },
];

export default function QuizFunnel({ isOpen, onClose }: QuizFunnelProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<QuizAnswer[]>([]);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [showResults, setShowResults] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const submitQuizMutation = trpc.quiz.submitQuizResults.useMutation();

  // Track quiz opened
  useEffect(() => {
    if (isOpen) {
      trackGTMEvent(GTMEvents.QUIZ_STARTED);
    }
  }, [isOpen]);

  const progress = ((currentStep + 1) / (QUIZ_QUESTIONS.length + 2)) * 100;

  const handleAnswer = (answer: string) => {
    const newAnswers = [
      ...answers.filter((a) => a.questionId !== QUIZ_QUESTIONS[currentStep].id),
      { questionId: QUIZ_QUESTIONS[currentStep].id, answer },
    ];
    setAnswers(newAnswers);

    // Auto-advance after selection
    setTimeout(() => {
      if (currentStep < QUIZ_QUESTIONS.length - 1) {
        setCurrentStep(currentStep + 1);
      } else {
        setCurrentStep(currentStep + 1); // Move to name input
      }
    }, 300);
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleNameSubmit = () => {
    if (name.trim()) {
      setCurrentStep(currentStep + 1); // Move to email
    }
  };

  const handleEmailSubmit = async () => {
    if (!email.trim() || !email.includes("@")) return;

    setIsSubmitting(true);

    try {
      // Get recommendation to extract product names
      const recommendation = getRecommendation();
      const recommendedProducts = recommendation.products.map((p) => p.name);

      // Prepare quiz answers object
      const quizAnswers: Record<string, any> = {};
      answers.forEach((a) => {
        const question = QUIZ_QUESTIONS.find((q) => q.id === a.questionId);
        if (question) {
          quizAnswers[`q${a.questionId}`] = a.answer;
        }
      });

      // Send to backend (which will forward to SALESmanago)
      await submitQuizMutation.mutateAsync({
        email,
        name: name || undefined,
        quizAnswers,
        recommendedProducts,
        ritualTitle: recommendation.title,
      });

      // Track events
      trackABTestEvent('email_captured');
      trackABTestEvent('quiz_completed');

      // Identify user in SALESmanago (smclient)
      identifySalesmanagoUser(email, name || undefined);
      
      // Track SALESmanago event
      trackSalesmanagoEvent("quiz_completed", {
        recommended_products: recommendedProducts.join(", "),
      });

      // Track GTM events (will forward to Facebook Pixel, GA, etc.)
      trackGTMEvent(GTMEvents.LEAD, {
        content_name: "Liptus Quiz Completed",
        content_category: "Quiz",
        value: 0,
        currency: "PLN",
      });
      trackGTMEvent(GTMEvents.QUIZ_COMPLETED, {
        recommended_products: recommendedProducts.join(", "),
        quiz_answers: quizAnswers,
      });

      // Show results
      setShowResults(true);
      toast.success("Dziękujemy! Twoje wyniki zostały zapisane.");

      // Track product recommendations viewed
      trackGTMEvent(GTMEvents.PRODUCT_RECOMMENDATION_VIEWED, {
        recommended_products: recommendedProducts.join(", "),
        num_products: recommendedProducts.length,
      });
    } catch (error: any) {
      console.error("Failed to submit quiz:", error);
      toast.error("Coś poszło nie tak. Spróbuj ponownie.");
      // Still show results even if SALESmanago fails
      setShowResults(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getRecommendation = () => {
    const goal = answers.find((a) => a.questionId === 1)?.answer;
    const format = answers.find((a) => a.questionId === 3)?.answer;

    // Simple recommendation logic
    if (goal === "breath" && format === "bath") {
      return {
        title: "Twój Rytuał: Oddech w Kąpieli",
        products: [
          {
            name: "Sól do kąpieli Liptus®",
            reason: "Idealna dla Ciebie, bo uwielbiasz długie kąpiele i potrzebujesz wsparcia dla oddechu.",
            price: "69,00 zł",
            link: "https://klaudynahebda.pl/sklep/",
          },
          {
            name: "Maść aromaterapeutyczna Liptus®",
            reason: "Uzupełni Twój rytuał - masaż klatki piersiowej po kąpieli.",
            price: "49,00 zł",
            link: "https://klaudynahebda.pl/sklep/",
          },
        ],
      };
    } else if (goal === "relax" && format === "bath") {
      return {
        title: "Twój Rytuał: Wieczorne Wyciszenie",
        products: [
          {
            name: "Koncentrat do kąpieli Liptus®",
            reason: "Skoncentrowana formuła dla głębokiego relaksu w kąpieli.",
            price: "39,00-59,00 zł",
            link: "https://klaudynahebda.pl/sklep/",
          },
          {
            name: "Herbatka ziołowa Liptus®",
            reason: "Idealnie dopełni Twój wieczorny rytuał, działając od wewnątrz.",
            price: "39,00 zł",
            link: "https://klaudynahebda.pl/sklep/",
          },
        ],
      };
    } else if (goal === "support") {
      return {
        title: "Twój Rytuał: Mobilne Wsparcie",
        products: [
          {
            name: "Roll-on Liptus®",
            reason: "Poręczny i dyskretny - idealny do torebki lub plecaka.",
            price: "49,00 zł",
            link: "https://klaudynahebda.pl/sklep/",
          },
          {
            name: "Maść aromaterapeutyczna Liptus®",
            reason: "Większy format na domowe użycie.",
            price: "49,00 zł",
            link: "https://klaudynahebda.pl/sklep/",
          },
        ],
      };
    } else if (format === "diffusion") {
      return {
        title: "Twój Rytuał: Aromatyczna Przestrzeń",
        products: [
          {
            name: "Olejek Liptus®",
            reason: "Bestseller! Idealny do dyfuzji i inhalacji.",
            price: "35,99-89,00 zł",
            link: "https://klaudynahebda.pl/sklep/zatoki-i/",
          },
          {
            name: "Spray Liptus® Light",
            reason: "Lżejsza wersja - do spryskania pościeli i pomieszczeń.",
            price: "59,00 zł",
            link: "https://klaudynahebda.pl/sklep/",
          },
        ],
      };
    }

    // Default recommendation
    return {
      title: "Twój Rytuał: Zestaw Startowy",
      products: [
        {
          name: "Zestaw Liptus®",
          reason: "Olejek, roll-on i sól - kompletny rytuał w jednym pakiecie.",
          price: "186,00 zł (zamiast 207 zł)",
          link: "https://klaudynahebda.pl/sklep/",
        },
      ],
    };
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-card">
        {/* Header */}
        <div className="sticky top-0 bg-card border-b p-6 flex items-center justify-between">
          <div className="flex-1">
            <Progress value={progress} className="h-2" />
            <p className="text-sm text-muted-foreground mt-2">
              Krok {currentStep + 1} z {QUIZ_QUESTIONS.length + 2}
            </p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6 md:p-8">
          {!showResults ? (
            <>
              {currentStep < QUIZ_QUESTIONS.length ? (
                // Question
                <div className="space-y-6 animate-fade-in">
                  <div>
                    <h2 className="text-3xl font-semibold mb-2">
                      {QUIZ_QUESTIONS[currentStep].question}
                    </h2>
                    <p className="text-muted-foreground">
                      {QUIZ_QUESTIONS[currentStep].subtitle}
                    </p>
                  </div>

                  <div className="grid gap-3">
                    {QUIZ_QUESTIONS[currentStep].options.map((option) => (
                      <Button
                        key={option.value}
                        variant="outline"
                        className="h-auto p-4 justify-start text-left hover:bg-primary/10 hover:border-primary transition-all"
                        onClick={() => handleAnswer(option.value)}
                      >
                        <span className="text-lg">{option.label}</span>
                      </Button>
                    ))}
                  </div>

                  {currentStep > 0 && (
                    <Button
                      variant="ghost"
                      onClick={handleBack}
                      className="mt-4"
                    >
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Wstecz
                    </Button>
                  )}
                </div>
              ) : currentStep === QUIZ_QUESTIONS.length ? (
                // Name input
                <div className="space-y-6 animate-fade-in">
                  <div>
                    <h2 className="text-3xl font-semibold mb-2">
                      Prawie gotowe! Jak masz na imię?
                    </h2>
                    <p className="text-muted-foreground">
                      Użyjemy go, aby spersonalizować Twoje wyniki.
                    </p>
                  </div>

                  <Input
                    type="text"
                    placeholder="Wpisz swoje imię"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="text-lg p-6"
                  />

                  <div className="flex gap-3">
                    <Button variant="ghost" onClick={handleBack}>
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Wstecz
                    </Button>
                    <Button
                      onClick={handleNameSubmit}
                      disabled={!name.trim()}
                      className="flex-1"
                    >
                      Dalej
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                </div>
              ) : (
                // Email input
                <div className="space-y-6 animate-fade-in">
                  <div>
                    <h2 className="text-3xl font-semibold mb-2">
                      {name}, Twój spersonalizowany rytuał jest gotowy!
                    </h2>
                    <p className="text-muted-foreground">
                      Podaj swój adres e-mail, aby otrzymać pełną analizę i{" "}
                      <strong>ekskluzywną zniżkę 15%</strong>.
                    </p>
                    <p className="text-sm text-primary mt-2">
                      💎 Na końcu quizu czeka na Ciebie kod rabatowy.
                    </p>
                  </div>

                  <Input
                    type="email"
                    placeholder="twoj@email.pl"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="text-lg p-6"
                  />

                  <p className="text-xs text-muted-foreground">
                    Nie wysyłamy spamu. Tylko wartościowe porady od Klaudyny
                    Hebdy.
                  </p>

                  <div className="flex gap-3">
                    <Button variant="ghost" onClick={handleBack}>
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Wstecz
                    </Button>
                    <Button
                      onClick={handleEmailSubmit}
                      disabled={!email.trim() || !email.includes("@") || isSubmitting}
                      className="flex-1"
                    >
                      {isSubmitting ? "Zapisuję..." : "Odbieram mój plan i zniżkę"}
                      {!isSubmitting && <ArrowRight className="w-4 h-4 ml-2" />}
                    </Button>
                  </div>
                </div>
              )}
            </>
          ) : (
            // Results
            <div className="space-y-8 animate-fade-in">
              <div>
                <h2 className="text-4xl font-semibold mb-4">
                  Cześć {name}! 👋
                </h2>
                <h3 className="text-2xl text-primary mb-2">
                  {getRecommendation().title}
                </h3>
                <p className="text-muted-foreground">
                  Na podstawie Twoich odpowiedzi przygotowaliśmy dla Ciebie
                  idealny zestaw produktów Liptus®.
                </p>
              </div>

              {/* Recommended products */}
              <div className="space-y-4">
                {getRecommendation().products.map((product, index) => (
                  <Card key={index} className="p-6 border-2 border-primary/20">
                    <div className="flex justify-between items-start mb-3">
                      <h4 className="text-xl font-semibold">{product.name}</h4>
                      <span className="text-lg font-bold text-primary">
                        {product.price}
                      </span>
                    </div>
                    <p className="text-muted-foreground mb-4">
                      <strong>Dlaczego dla Ciebie:</strong> {product.reason}
                    </p>
                    <Button
                      className="w-full"
                      onClick={() => {
                        // Track GTM InitiateCheckout
                        trackGTMEvent(GTMEvents.INITIATE_CHECKOUT, {
                          content_name: product.name,
                          content_category: "Liptus Product",
                          value: parseFloat(product.price.replace(/[^0-9,]/g, "").replace(",", ".")),
                          currency: "PLN",
                        });
                        window.open(product.link, "_blank");
                      }}
                    >
                      Dodaj do Koszyka
                    </Button>
                  </Card>
                ))}
              </div>

              {/* Special offer with countdown */}
              <Card className="p-6 bg-primary/5 border-primary">
                <h4 className="text-xl font-semibold mb-2">
                  🎁 Twoja ekskluzywna zniżka
                </h4>
                <p className="text-muted-foreground mb-4">
                  Użyj kodu <strong className="text-primary">QUIZ15</strong>{" "}
                  przy zakupie, aby otrzymać 15% zniżki na swój pierwszy
                  zestaw!
                </p>
                
                {/* Countdown */}
                <div className="bg-card rounded-lg p-4 mb-4">
                  <div className="flex items-center justify-center gap-2 mb-3">
                    <Clock className="w-4 h-4 text-destructive" />
                    <p className="text-sm font-semibold text-destructive">
                      Oferta ważna jeszcze:
                    </p>
                  </div>
                  <CountdownTimer endOfDay={true} />
                </div>
                
                <p className="text-sm text-muted-foreground">
                  Nie przegap! Zniżka dostępna tylko dziś.
                </p>
              </Card>

              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  trackGTMEvent(GTMEvents.VIEW_CONTENT, {
                    content_name: "All Liptus Products",
                    content_category: "Product Catalog",
                  });
                  window.open("https://klaudynahebda.pl/sklep/seria-liptus/", "_blank");
                }}
              >
                Zobacz wszystkie produkty Liptus®
              </Button>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
