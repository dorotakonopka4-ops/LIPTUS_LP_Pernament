/**
 * Design Philosophy: Modern Apothecary meets Scandinavian Minimalism
 * - Sage green primary color with warm cream background
 * - Clean, elegant typography (Playfair Display + Inter)
 * - Subtle animations and generous whitespace
 */

import { X } from "lucide-react";
import { useState } from "react";

export default function DiscountBanner() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <div className="sticky top-0 z-50 bg-primary text-primary-foreground shadow-md">
      <div className="container">
        <div className="flex items-center justify-between py-3 gap-4">
          {/* First purchase discount */}
          <div className="flex-1 flex items-center justify-center text-sm md:text-base">
            <span className="font-semibold">🎁 Zniżka 15% na Twój pierwszy zakup</span>
          </div>

          {/* Close button */}
          <button
            onClick={() => setIsVisible(false)}
            className="p-1 hover:bg-primary-foreground/10 rounded-full transition-colors"
            aria-label="Zamknij banner"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
